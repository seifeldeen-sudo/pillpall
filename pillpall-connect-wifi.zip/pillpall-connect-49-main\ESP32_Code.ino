#include <WiFi.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include <ESP32Servo.h>

// ======= EDIT THESE TWO LINES to match your mobile hotspot =======
const char* WIFI_SSID     = "YOUR_HOTSPOT_NAME";
const char* WIFI_PASSWORD = "YOUR_HOTSPOT_PASSWORD";
// =================================================================

#define MOTOR_PIN  4
#define BUZZER_PIN 10  // GPIO 12 doesn't exist on the C3 Super Mini; 10 is free

WebServer server(80);
Servo motorServo;

bool isLocked = true;
unsigned long unlockTimestamp = 0;
bool warningPlayed = false;
bool pendingLocate = false;  // set by HTTP handler, played in loop()

void setLocked() {
  Serial.println("LOCKED");
  motorServo.write(0);   // return motor to base position
  isLocked = true;
  warningPlayed = false;
}

void setUnlocked() {
  Serial.println("UNLOCKED");
  motorServo.write(60);  // move motor to unlock indicator position
  isLocked = false;
  unlockTimestamp = millis();
  warningPlayed = false;
}

void playWarningTone() {
  int toneFreq = 1200;
  for (int i = 0; i < 3; i++) {
    tone(BUZZER_PIN, toneFreq);
    delay(200);
    noTone(BUZZER_PIN);
    delay(150);
  }
}

void playMorseExclamation() {
  // Morse code for !: --..--
  int unit = 200;
  int dash = 3 * unit;
  int dot = unit;
  int symbolSpace = unit;
  int letterSpace = 3 * unit;
  int toneFreq = 1000;

  auto buzz = [&](int duration) {
    tone(BUZZER_PIN, toneFreq);
    delay(duration);
    noTone(BUZZER_PIN);
  };

  buzz(dash); delay(symbolSpace);
  buzz(dash); delay(letterSpace);
  buzz(dot);  delay(symbolSpace);
  buzz(dot);  delay(letterSpace);
  buzz(dash); delay(symbolSpace);
  buzz(dash);
}

void testBuzzer() {
  Serial.println("Testing buzzer...");
  tone(BUZZER_PIN, 1000);
  delay(500);
  noTone(BUZZER_PIN);
  delay(500);
  tone(BUZZER_PIN, 2000);
  delay(500);
  noTone(BUZZER_PIN);
  Serial.println("Buzzer test complete");
}

// ======= HTTP HELPERS =======

String stateJson() {
  return String("{\"locked\":") + (isLocked ? "true" : "false") + "}";
}

void sendJson(const String& body) {
  server.sendHeader("Access-Control-Allow-Origin", "*");  // let the web app call us
  server.send(200, "application/json", body);
}

// ======= HTTP HANDLERS =======

void handleRoot() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.send(200, "text/plain", "PillPall ESP32 is running. Endpoints: /status /toggle /lock /unlock /locate");
}

void handleStatus() {
  sendJson(stateJson());
}

void handleToggle() {
  if (isLocked) setUnlocked(); else setLocked();
  Serial.print("Toggle -> ");
  Serial.println(isLocked ? "LOCKED" : "UNLOCKED");
  sendJson(stateJson());
}

void handleLock() {
  if (!isLocked) setLocked();
  sendJson(stateJson());
}

void handleUnlock() {
  if (isLocked) setUnlocked();
  sendJson(stateJson());
}

void handleLocate() {
  Serial.println("LOCATE COMMAND RECEIVED");
  pendingLocate = true;  // play after responding so the app isn't kept waiting
  sendJson("{\"locate\":\"ok\"}");
}

void handleNotFound() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.send(404, "text/plain", "Unknown command");
}

void connectWiFi() {
  WiFi.mode(WIFI_STA);
  // C3 Super Mini boards often fail to connect at full TX power (antenna issue)
  WiFi.setTxPower(WIFI_POWER_8_5dBm);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  Serial.print("Connecting to WiFi");
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 20000) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("WiFi connected!");
    Serial.print(">>> DEVICE IP ADDRESS: ");
    Serial.println(WiFi.localIP());
    Serial.println(">>> Enter this IP in the PillPall app");
  } else {
    Serial.println("WiFi connection FAILED - check SSID/password, will keep retrying in loop");
  }
}

void setup() {
  Serial.begin(115200);

  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  motorServo.attach(MOTOR_PIN);

  setLocked(); // start locked

  testBuzzer();

  connectWiFi();

  if (MDNS.begin("pillpall")) {
    Serial.println("mDNS started: http://pillpall.local");
  }

  server.on("/", handleRoot);
  server.on("/status", handleStatus);
  server.on("/toggle", handleToggle);
  server.on("/lock", handleLock);
  server.on("/unlock", handleUnlock);
  server.on("/locate", handleLocate);
  server.onNotFound(handleNotFound);
  server.begin();
  Serial.println("HTTP server started - WIFI READY");
}

void loop() {
  server.handleClient();

  // Reconnect if the hotspot dropped us
  static unsigned long lastWifiCheck = 0;
  if (millis() - lastWifiCheck > 10000) {
    lastWifiCheck = millis();
    if (WiFi.status() != WL_CONNECTED) {
      Serial.println("WiFi lost - reconnecting...");
      WiFi.reconnect();
    } else {
      static bool ipPrinted = false;
      if (!ipPrinted) {
        Serial.print(">>> DEVICE IP ADDRESS: ");
        Serial.println(WiFi.localIP());
        ipPrinted = true;
      }
    }
  }

  if (pendingLocate) {
    pendingLocate = false;
    playMorseExclamation();
  }

  // 10-second unlocked warning
  if (!isLocked && !warningPlayed && unlockTimestamp > 0 && millis() - unlockTimestamp >= 10000) {
    Serial.println("WARNING: unlocked for 10 seconds");
    playWarningTone();
    warningPlayed = true;
  }

  delay(2);
}
