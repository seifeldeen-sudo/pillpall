import { useEffect, useState } from "react";
import { ArrowLeft, Bluetooth, Check, Loader2, Smartphone, Search, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface DevicePairingScreenProps {
  onClose: () => void;
  onPaired?: (deviceId: string) => void;
}

type Stage = "intro" | "scanning" | "found" | "pairing" | "code" | "success";

interface FoundDevice {
  id: string;
  name: string;
  serial: string;
  rssi: number;
}

// Web Bluetooth API types
declare global {
  interface Navigator {
    bluetooth: Bluetooth;
  }
}

interface Bluetooth {
  requestDevice(options: BluetoothRequestDeviceOptions): Promise<BluetoothDevice>;
}

interface BluetoothRequestDeviceOptions {
  filters?: BluetoothLEScanFilter[];
  optionalServices?: BluetoothServiceUUID[];
  acceptAllDevices?: boolean;
}

interface BluetoothLEScanFilter {
  name?: string;
  services?: BluetoothServiceUUID[];
}

type BluetoothServiceUUID = string;

interface BluetoothDevice {
  id: string;
  name?: string;
  gatt?: BluetoothRemoteGATTServer;
}

const DevicePairingScreen = ({ onClose, onPaired }: DevicePairingScreenProps) => {
  const [stage, setStage] = useState<Stage>("intro");
  const [devices, setDevices] = useState<FoundDevice[]>([]);
  const [selected, setSelected] = useState<FoundDevice | null>(null);
  const [debugMode, setDebugMode] = useState(false);
  const [code, setCode] = useState("");
  const [progress, setProgress] = useState(0);

  // Animate the pairing progress bar while connecting
  useEffect(() => {
    if (stage !== "pairing") {
      setProgress(0);
      return;
    }
    const interval = setInterval(() => {
      setProgress((p) => (p < 90 ? p + 5 : p));
    }, 150);
    return () => clearInterval(interval);
  }, [stage]);

  // Debug function to show all BLE devices
  const debugScan = async () => {
    try {
      setDebugMode(true);
      const device = await navigator.bluetooth.requestDevice({
        acceptAllDevices: true
      });
      console.log("Found device:", {
        name: device.name,
        id: device.id,
        gatt: !!device.gatt
      });
      alert(`Found: ${device.name || 'Unknown'} (ID: ${device.id})`);
      setDebugMode(false);
    } catch (error) {
      console.error("Debug scan failed:", error);
      alert("Debug scan failed: " + error);
      setDebugMode(false);
    }
  };

  // Real Bluetooth scanning
  useEffect(() => {
    if (stage !== "scanning") return;

    const scanForDevices = async () => {
      try {
        setDevices([]);
        // Request device with acceptAllDevices to see all BLE devices
        const device = await navigator.bluetooth.requestDevice({
          acceptAllDevices: true,
          optionalServices: ["12345678-1234-1234-1234-123456789abc"] // Our ESP32 service UUID
        });

        // First, try to find our specific device
        if (device.name && (device.name.includes("ESP32") || device.name.includes("PillPall") || device.name.includes("LOCK"))) {
          const foundDevice: FoundDevice = {
            id: device.id,
            name: device.name || "Unknown Device",
            serial: device.id.slice(-6).toUpperCase(),
            rssi: -50
          };
          setDevices([foundDevice]);
          setStage("found");
        } else {
          // If no specific device found, show a message but don't fail
          console.log("Found device:", device.name || "Unknown", "ID:", device.id);
          toast.error("No PillPall devices found. Make sure your ESP32 is powered on and nearby.");
          setStage("intro");
        }
      } catch (error) {
        console.error("Bluetooth scan failed:", error);
        toast.error("Bluetooth scan failed. Make sure Bluetooth is enabled.");
        setStage("intro");
      }
    };

    scanForDevices();
  }, [stage]);

  // Remove pairing progress simulation - we do real connection now
  useEffect(() => {
    // No longer needed
  }, []);

  const handleStart = () => setStage("scanning");

  const handleSelect = async (d: FoundDevice) => {
    setSelected(d);
    setStage("pairing");

    try {
      // Actually connect to the device
      const device = await navigator.bluetooth.requestDevice({
        filters: [{ name: d.name }],
        optionalServices: ["12345678-1234-1234-1234-123456789abc"]
      });

      const server = await device.gatt!.connect();
      const service = await server.getPrimaryService("12345678-1234-1234-1234-123456789abc");
      const characteristic = await service.getCharacteristic("abcd1234-1234-1234-1234-123456789abc");

      // Store the connection somehow - we'll need to pass this back
      setStage("code");
      toast.success("Device connected! Enter the pairing code.");
    } catch (error) {
      console.error("Device connection failed:", error);
      toast.error("Failed to connect to device");
      setStage("found");
    }
  };

  const handleVerify = () => {
    // Skip code verification for Web Bluetooth - connection is pairing
    setStage("success");
    toast.success("Device paired successfully");
    if (selected) onPaired?.(selected.id);
  };

  const handleDone = () => {
    onClose();
  };

  const signalBars = (rssi: number) => {
    if (rssi > -55) return 4;
    if (rssi > -65) return 3;
    if (rssi > -75) return 2;
    return 1;
  };

  return (
    <div className="fixed inset-0 z-[60] bg-background flex flex-col max-w-md mx-auto">
      {/* Header */}
      <header className="px-5 pt-6 pb-4 flex items-center gap-3 border-b border-border">
        <button
          onClick={onClose}
          className="w-9 h-9 rounded-lg hover:bg-accent flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
          aria-label="Back"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-lg font-semibold text-foreground">Pair Device</h1>
          <p className="text-xs text-muted-foreground">
            {stage === "intro" && "Connect your PillPall to this phone"}
            {stage === "scanning" && "Searching for nearby devices..."}
            {stage === "found" && "Select your device"}
            {stage === "pairing" && "Establishing secure connection"}
            {stage === "code" && "Verify the pairing code"}
            {stage === "success" && "All set!"}
          </p>
        </div>
      </header>

      {/* Body */}
      <main className="flex-1 px-5 py-6 overflow-y-auto">
        {stage === "intro" && (
          <div className="space-y-6">
            <div className="flex items-center justify-center gap-6 py-8">
              <div className="w-20 h-20 rounded-2xl gradient-primary flex items-center justify-center">
                <Smartphone className="w-10 h-10 text-primary-foreground" />
              </div>
              <div className="flex flex-col gap-1.5">
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse [animation-delay:150ms]" />
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse [animation-delay:300ms]" />
              </div>
              <div className="w-20 h-20 rounded-2xl bg-muted flex items-center justify-center">
                <Bluetooth className="w-10 h-10 text-muted-foreground" />
              </div>
            </div>

            <div className="glass-card rounded-xl p-5 space-y-4">
              <p className="text-sm font-semibold text-card-foreground">Before you start</p>
              <ul className="space-y-3 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-success mt-0.5 shrink-0" />
                  Make sure the device is powered on
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-success mt-0.5 shrink-0" />
                  Hold the pair button until the LED flashes blue
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-success mt-0.5 shrink-0" />
                  Keep the device within 3 feet of your phone
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-success mt-0.5 shrink-0" />
                  Bluetooth is enabled on your phone
                </li>
              </ul>
            </div>

            <Button className="w-full gap-2" size="lg" onClick={handleStart}>
              <Search className="w-4 h-4" /> Start Scanning
            </Button>

            <Button
              variant="outline"
              className="w-full gap-2"
              size="lg"
              onClick={debugScan}
              disabled={debugMode}
            >
              {debugMode ? <Loader2 className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
              Debug: Show All BLE Devices
            </Button>
          </div>
        )}

        {stage === "scanning" && (
          <div className="space-y-6">
            <div className="flex flex-col items-center justify-center py-10">
              <div className="relative w-32 h-32 flex items-center justify-center">
                <span className="absolute inset-0 rounded-full bg-primary/10 animate-ping" />
                <span className="absolute inset-3 rounded-full bg-primary/15 animate-ping [animation-delay:200ms]" />
                <div className="relative w-20 h-20 rounded-full gradient-primary flex items-center justify-center">
                  <Bluetooth className="w-10 h-10 text-primary-foreground" />
                </div>
              </div>
              <p className="mt-6 text-sm font-medium text-foreground">Scanning for devices</p>
              <p className="text-xs text-muted-foreground">This usually takes a few seconds</p>
            </div>

            {devices.length > 0 && (
              <div className="space-y-2">
                <p className="text-[10px] font-semibold text-primary uppercase tracking-wide">Found</p>
                {devices.map((d) => (
                  <div key={d.id} className="glass-card rounded-xl p-4 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-accent flex items-center justify-center">
                      <Bluetooth className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-card-foreground">{d.name}</p>
                      <p className="text-xs text-muted-foreground">{d.serial}</p>
                    </div>
                    <Loader2 className="w-4 h-4 text-muted-foreground animate-spin" />
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {stage === "found" && (
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Found {devices.length} device{devices.length !== 1 ? "s" : ""} nearby. Tap one to pair.
            </p>
            {devices.map((d) => {
              const bars = signalBars(d.rssi);
              return (
                <button
                  key={d.id}
                  onClick={() => handleSelect(d)}
                  className="w-full glass-card rounded-xl p-4 flex items-center gap-3 hover:border-primary/40 transition-colors text-left"
                >
                  <div className="w-11 h-11 rounded-lg gradient-primary flex items-center justify-center shrink-0">
                    <Bluetooth className="w-5 h-5 text-primary-foreground" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-card-foreground">{d.name}</p>
                    <p className="text-xs text-muted-foreground">{d.serial}</p>
                  </div>
                  <div className="flex items-end gap-0.5 h-5">
                    {[1, 2, 3, 4].map((b) => (
                      <span
                        key={b}
                        className={cn(
                          "w-1 rounded-sm",
                          b === 1 && "h-1.5",
                          b === 2 && "h-2.5",
                          b === 3 && "h-3.5",
                          b === 4 && "h-5",
                          b <= bars ? "bg-primary" : "bg-muted",
                        )}
                      />
                    ))}
                  </div>
                </button>
              );
            })}
            <Button variant="outline" className="w-full" onClick={() => setStage("scanning")}>
              Scan again
            </Button>
          </div>
        )}

        {stage === "pairing" && selected && (
          <div className="space-y-6">
            <div className="flex flex-col items-center py-10">
              <div className="w-20 h-20 rounded-2xl gradient-primary flex items-center justify-center mb-4">
                <Loader2 className="w-10 h-10 text-primary-foreground animate-spin" />
              </div>
              <p className="text-sm font-semibold text-foreground">Pairing with {selected.serial}</p>
              <p className="text-xs text-muted-foreground mt-1">Please keep the device close</p>
            </div>
            <div className="w-full h-2 rounded-full bg-muted overflow-hidden">
              <div
                className="h-full gradient-primary transition-all duration-150"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="text-center text-xs text-muted-foreground">{progress}%</p>
          </div>
        )}

        {stage === "code" && (
          <div className="space-y-6">
            <div className="glass-card rounded-xl p-5 space-y-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-primary" />
                <p className="text-sm font-semibold text-card-foreground">Verify the code</p>
              </div>
              <p className="text-xs text-muted-foreground">
                Enter the 6-digit code displayed on your device's screen to complete pairing.
              </p>
              <input
                type="text"
                inputMode="numeric"
                maxLength={6}
                placeholder="••••••"
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))}
                className="w-full bg-accent/50 border border-border rounded-xl px-4 py-4 text-center text-2xl font-mono tracking-[0.5em] text-foreground placeholder:text-muted-foreground outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/20"
              />
            </div>
            <Button className="w-full" size="lg" onClick={handleVerify}>
              Verify & Pair
            </Button>
            <button
              onClick={() => toast("New code requested on device")}
              className="w-full text-xs text-muted-foreground hover:text-foreground transition-colors"
            >
              Didn't see a code? Request a new one
            </button>
          </div>
        )}

        {stage === "success" && selected && (
          <div className="space-y-6">
            <div className="flex flex-col items-center py-10">
              <div className="w-20 h-20 rounded-full bg-success/15 flex items-center justify-center mb-4">
                <Check className="w-10 h-10 text-success" />
              </div>
              <p className="text-base font-semibold text-foreground">Device Paired!</p>
              <p className="text-sm text-muted-foreground mt-1">
                {selected.serial} is now connected
              </p>
            </div>
            <div className="glass-card rounded-xl p-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Device</span>
                <span className="font-medium text-card-foreground">{selected.name}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Serial</span>
                <span className="font-medium text-card-foreground">{selected.serial}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Status</span>
                <span className="font-medium text-success">Connected</span>
              </div>
            </div>
            <Button className="w-full" size="lg" onClick={handleDone}>
              Done
            </Button>
          </div>
        )}
      </main>
    </div>
  );
};

export default DevicePairingScreen;
