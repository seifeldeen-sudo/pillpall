import { useState, useEffect, useRef, useCallback } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

import Index from "./pages/Index.tsx";
import NotFound from "./pages/NotFound.tsx";

const queryClient = new QueryClient();

// ===== WIFI CONFIG =====
// The ESP32 prints its IP address in the Arduino Serial Monitor on boot.
// The app asks for it once and remembers it (localStorage).
const IP_STORAGE_KEY = "pillpall_ip";
const POLL_INTERVAL_MS = 2000;

const App = () => {
  const [deviceIp, setDeviceIp] = useState<string | null>(
    () => localStorage.getItem(IP_STORAGE_KEY)
  );
  const [isLocked, setIsLocked] = useState(true);
  const [connected, setConnected] = useState(false);
  const failCountRef = useRef(0);

  // fetch with a timeout so a dead device doesn't hang the app
  async function fetchDevice(ip: string, path: string, timeoutMs = 4000) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await fetch(`http://${ip}${path}`, { signal: ctrl.signal });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } finally {
      clearTimeout(timer);
    }
  }

  // 🔌 CONNECT TO ESP32 (kept the name connectBLE so the rest of the app doesn't change)
  async function connectBLE() {
    const suggested = deviceIp || "192.168.";
    const input = window.prompt(
      "Enter your PillPall's IP address\n(shown in the Arduino Serial Monitor after '>>> DEVICE IP ADDRESS')",
      suggested
    );
    if (!input) return;
    const ip = input.trim();

    try {
      const data = await fetchDevice(ip, "/status");
      setIsLocked(!!data.locked);
      setDeviceIp(ip);
      localStorage.setItem(IP_STORAGE_KEY, ip);
      failCountRef.current = 0;
      setConnected(true);
      console.log("WiFi connected to PillPall at", ip);
    } catch (err) {
      console.error("WiFi connect failed:", err);
      alert(
        "Could not reach the device at " +
          ip +
          ".\n\nCheck that:\n- The ESP32 is powered on\n- Your hotspot is on and the ESP32 joined it\n- This phone/PC is on the same network\n- The IP matches the Serial Monitor"
      );
    }
  }

  // 🔓 TOGGLE LOCK
  async function toggleLock() {
    if (!connected || !deviceIp) {
      console.log("Not connected");
      return;
    }
    try {
      const data = await fetchDevice(deviceIp, "/toggle");
      setIsLocked(!!data.locked);
    } catch (err) {
      console.error("Toggle failed:", err);
    }
  }

  // 📍 LOCATE DEVICE (Morse code !)
  async function locateDevice() {
    if (!connected || !deviceIp) {
      console.log("Not connected");
      return;
    }
    try {
      await fetchDevice(deviceIp, "/locate");
      console.log("Locate command sent");
    } catch (err) {
      console.error("Locate failed:", err);
    }
  }

  // 🔄 POLL DEVICE STATUS while connected — keeps lock state in sync
  // and detects when the device goes offline
  useEffect(() => {
    if (!connected || !deviceIp) return;

    const poll = setInterval(async () => {
      try {
        const data = await fetchDevice(deviceIp, "/status", 3000);
        setIsLocked(!!data.locked);
        failCountRef.current = 0;
      } catch {
        failCountRef.current += 1;
        if (failCountRef.current >= 3) {
          console.log("Device unreachable - marking disconnected");
          setConnected(false);
        }
      }
    }, POLL_INTERVAL_MS);

    return () => clearInterval(poll);
  }, [connected, deviceIp]);

  // ⏱️ AUTO-LOCK AFTER 30 SECONDS OF INACTIVITY
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const resetAutoLockTimer = useCallback(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }
    if (connected && deviceIp) {
      timerRef.current = setTimeout(async () => {
        console.log("Auto-lock triggered after 30s");
        try {
          // /lock only locks (never accidentally unlocks, unlike toggle)
          const data = await fetchDevice(deviceIp, "/lock");
          setIsLocked(!!data.locked);
        } catch (err) {
          console.error("Auto-lock failed:", err);
        }
      }, 30000);
    }
  }, [connected, deviceIp]);

  // Start timer on connect, reset on any interaction
  useEffect(() => {
    if (connected) {
      resetAutoLockTimer();
    }
    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, [connected, resetAutoLockTimer]);

  // Reset timer on user interaction
  const handleUserActivity = useCallback(() => {
    resetAutoLockTimer();
  }, [resetAutoLockTimer]);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />

        <BrowserRouter>
          <Routes>
            {/* 👇 same prop shape as before, now backed by WiFi instead of BLE */}
            <Route
              path="/"
              element={
                <Index
                  ble={{
                    connectBLE,
                    toggleLock,
                    locateDevice,
                    isLocked,
                    connected,
                    resetAutoLock: handleUserActivity,
                  }}
                />
              }
            />

            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
