import { Send, Stethoscope, Phone, Video, ChevronLeft } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { chatStore, useChats } from "@/lib/chatStore";
import { cn } from "@/lib/utils";

const DoctorCommsScreen = () => {
  const chats = useChats();
  const [activeId, setActiveId] = useState<string | null>(null);
  const [input, setInput] = useState("");

  const activeChat = chats.find((c) => c.id === activeId) ?? null;

  const handleSend = () => {
    if (!input.trim() || !activeChat) return;
    chatStore.sendMessage(activeChat.id, input.trim());
    toast.success(`Message sent to ${activeChat.doctorName}`);
    setInput("");
  };

  const getInitials = (name: string) =>
    name.replace("Dr. ", "").split(" ").map((n) => n[0]).join("");

  // Chat list view
  if (!activeChat) {
    return (
      <div className="flex flex-col h-[calc(100vh-10rem)]">
        <div className="mb-4">
          <h2 className="text-lg font-semibold text-foreground">Messages</h2>
          <p className="text-sm text-muted-foreground">{chats.length} conversation{chats.length !== 1 ? "s" : ""}</p>
        </div>
        <div className="flex-1 overflow-y-auto space-y-3">
          {chats.length === 0 && (
            <div className="text-center py-12 text-sm text-muted-foreground">
              No conversations yet. Connect with a doctor to start chatting.
            </div>
          )}
          {chats.map((c, i) => {
            const last = c.messages[c.messages.length - 1];
            return (
              <button
                key={c.id}
                onClick={() => setActiveId(c.id)}
                style={{ animationDelay: `${i * 60}ms`, animationFillMode: "backwards" }}
                className="w-full glass-card rounded-xl p-4 flex items-center gap-3 text-left transition-all animate-fade-in hover:scale-[1.01] active:scale-[0.99]"
              >
                <div className="w-11 h-11 rounded-full gradient-primary flex items-center justify-center shrink-0">
                  <span className="text-sm font-semibold text-primary-foreground">{getInitials(c.doctorName)}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <p className="font-semibold text-card-foreground text-sm truncate">{c.doctorName}</p>
                    <span className="text-[10px] text-muted-foreground shrink-0">{last?.time}</span>
                  </div>
                  <p className="text-xs text-primary truncate">{c.specialty} · {c.hospital}</p>
                  <p className="text-xs text-muted-foreground truncate mt-0.5">{last?.text}</p>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  // Conversation view
  return (
    <div className="flex flex-col h-[calc(100vh-10rem)]">
      <div className="mb-4 flex items-center gap-2">
        <button
          onClick={() => setActiveId(null)}
          className="w-8 h-8 rounded-full bg-accent flex items-center justify-center text-accent-foreground hover:bg-accent/80 transition-all active:scale-95"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
        <h2 className="text-lg font-semibold text-foreground">Messages</h2>
      </div>

      {/* Doctor info card */}
      <div className="glass-card rounded-xl p-4 mb-4 flex items-center justify-between animate-fade-in">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-full gradient-primary flex items-center justify-center">
            <Stethoscope className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <p className="font-semibold text-card-foreground text-sm">{activeChat.doctorName}</p>
            <p className="text-xs text-muted-foreground">{activeChat.specialty} · {activeChat.hospital}</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button className="w-9 h-9 rounded-full bg-accent flex items-center justify-center text-accent-foreground hover:bg-accent/80 transition-all active:scale-95 hover:scale-105">
            <Phone className="w-4 h-4" />
          </button>
          <button className="w-9 h-9 rounded-full bg-accent flex items-center justify-center text-accent-foreground hover:bg-accent/80 transition-all active:scale-95 hover:scale-105">
            <Video className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto space-y-3 mb-4">
        {activeChat.messages.map((msg, i) => (
          <div
            key={msg.id}
            className={cn("flex animate-fade-in", msg.from === "you" ? "justify-end" : "justify-start")}
            style={{ animationDelay: `${i * 60}ms`, animationFillMode: "backwards" }}
          >
            <div className={cn(
              "max-w-[80%] rounded-2xl px-4 py-2.5",
              msg.from === "you"
                ? "bg-primary text-primary-foreground rounded-br-md"
                : "glass-card rounded-bl-md"
            )}>
              <p className={cn("text-sm", msg.from === "you" ? "" : "text-card-foreground")}>{msg.text}</p>
              <p className={cn("text-[10px] mt-1", msg.from === "you" ? "text-primary-foreground/60" : "text-muted-foreground")}>{msg.time}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Input */}
      <div className="glass-card rounded-xl p-2 flex items-center gap-2">
        <input
          type="text"
          placeholder={`Message ${activeChat.doctorName}...`}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
          className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground outline-none px-3 py-2"
        />
        <Button size="icon" className="shrink-0 h-9 w-9 rounded-lg" onClick={handleSend}>
          <Send className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
};

export default DoctorCommsScreen;
