import { useState } from "react";
import { Search, Check, UserPlus, Clock, X, MapPin, Star, MessageCircle, UserCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { chatStore } from "@/lib/chatStore";

type ConnectionStatus = "connected" | "pending" | "incoming" | "none";

interface Doctor {
  id: number;
  name: string;
  specialty: string;
  hospital: string;
  location: string;
  rating: number;
  mutual: number;
  avatar?: string;
  status: ConnectionStatus;
}

const allDoctors: Doctor[] = [
  { id: 1, name: "Dr. Sarah Patel", specialty: "Cardiology", hospital: "St. Mary's General Hospital", location: "Downtown", rating: 4.9, mutual: 3, status: "connected" },
  { id: 2, name: "Dr. James Chen", specialty: "Internal Medicine", hospital: "University Medical Center", location: "Midtown", rating: 4.8, mutual: 1, status: "pending" },
  { id: 3, name: "Dr. Maria Lopez", specialty: "General Practice", hospital: "Riverside Community Hospital", location: "Eastside", rating: 4.7, mutual: 2, status: "incoming" },
  { id: 4, name: "Dr. Robert Adams", specialty: "Neurology", hospital: "Memorial Regional Hospital", location: "Northside", rating: 4.9, mutual: 0, status: "incoming" },
  { id: 5, name: "Dr. Emily Kim", specialty: "Oncology", hospital: "Cedar Valley Medical Center", location: "Suburbs", rating: 4.6, mutual: 1, status: "none" },
  { id: 6, name: "Dr. David Wright", specialty: "Orthopedics", hospital: "City Health Clinic", location: "Westside", rating: 4.5, mutual: 4, status: "none" },
];

type FilterTab = "all" | "connected" | "pending" | "requests";

const ConnectionScreen = () => {
  const [doctors, setDoctors] = useState<Doctor[]>(allDoctors);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<FilterTab>("all");

  const filtered = doctors.filter((d) => {
    const matchesQuery =
      d.name.toLowerCase().includes(query.toLowerCase()) ||
      d.specialty.toLowerCase().includes(query.toLowerCase()) ||
      d.hospital.toLowerCase().includes(query.toLowerCase());
    if (filter === "connected") return matchesQuery && d.status === "connected";
    if (filter === "pending") return matchesQuery && d.status === "pending";
    if (filter === "requests") return matchesQuery && d.status === "incoming";
    return matchesQuery;
  });

  const handleConnect = (id: number) => {
    setDoctors((prev) =>
      prev.map((d) => (d.id === id ? { ...d, status: "pending" as ConnectionStatus } : d))
    );
    toast.success("Connection request sent");
  };

  const handleCancel = (id: number) => {
    setDoctors((prev) =>
      prev.map((d) => (d.id === id ? { ...d, status: "none" as ConnectionStatus } : d))
    );
    toast("Request cancelled");
  };

  const handleAccept = (id: number) => {
    const doc = doctors.find((d) => d.id === id);
    setDoctors((prev) =>
      prev.map((d) => (d.id === id ? { ...d, status: "connected" as ConnectionStatus } : d))
    );
    if (doc) {
      chatStore.addChat({
        id: `doc-${doc.id}`,
        doctorName: doc.name,
        specialty: doc.specialty,
        hospital: doc.hospital,
      });
      toast.success(`Connected with ${doc.name} — chat opened in Messages`);
    } else {
      toast.success("Connection accepted");
    }
  };

  const handleDecline = (id: number) => {
    setDoctors((prev) =>
      prev.map((d) => (d.id === id ? { ...d, status: "none" as ConnectionStatus } : d))
    );
    toast("Request declined");
  };

  const connectedCount = doctors.filter((d) => d.status === "connected").length;
  const pendingCount = doctors.filter((d) => d.status === "pending").length;
  const incomingCount = doctors.filter((d) => d.status === "incoming").length;

  const getInitials = (name: string) =>
    name.replace("Dr. ", "").split(" ").map((n) => n[0]).join("");

  const filterTabs: { id: FilterTab; label: string; count?: number }[] = [
    { id: "all", label: "All" },
    { id: "connected", label: "Connected", count: connectedCount },
    { id: "requests", label: "Requests", count: incomingCount },
    { id: "pending", label: "Pending", count: pendingCount },
  ];

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-lg font-semibold text-foreground">My Doctors</h2>
        <p className="text-sm text-muted-foreground">
          {connectedCount} connected · {pendingCount} pending · {incomingCount} request{incomingCount !== 1 ? "s" : ""}
        </p>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          type="text"
          placeholder="Search doctors, specialties, hospitals..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="w-full bg-accent/50 border border-border rounded-xl pl-10 pr-4 py-3 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/20 transition-all"
        />
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2">
        {filterTabs.map((f, i) => (
          <button
            key={f.id}
            onClick={() => setFilter(f.id)}
            style={{ animationDelay: `${i * 50}ms`, animationFillMode: "backwards" }}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 animate-fade-in active:scale-95 hover:scale-[1.03]",
              filter === f.id
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground hover:text-foreground"
            )}
          >
            {f.label}
            {f.count !== undefined && f.count > 0 && (
              <span className={cn(
                "w-4.5 h-4.5 rounded-full text-[10px] flex items-center justify-center min-w-[18px] px-1",
                filter === f.id
                  ? "bg-primary-foreground/20 text-primary-foreground"
                  : f.id === "requests" ? "bg-destructive/15 text-destructive" : "bg-border text-muted-foreground"
              )}>
                {f.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Doctor Cards */}
      <div className="space-y-3 max-h-[420px] overflow-y-auto">
        {filtered.length === 0 && (
          <div className="text-center py-8">
            <UserPlus className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">No doctors found</p>
          </div>
        )}
        {/* Connection Requests section */}
        {filtered.some((d) => d.status === "incoming") && (
          <p className="text-[10px] font-semibold text-primary uppercase tracking-wide">
            Connection Requests
          </p>
        )}
        {filtered.filter((d) => d.status === "incoming").map((doc, i) => (
          <div
            key={doc.id}
            style={{ animationDelay: `${i * 60}ms`, animationFillMode: "backwards" }}
            className="glass-card rounded-xl p-4 transition-all border-primary/20 bg-primary/[0.02] animate-fade-in hover:scale-[1.01]"
          >
            <div className="flex items-start gap-3">
              <Avatar className="w-12 h-12 shrink-0">
                {doc.avatar && <AvatarImage src={doc.avatar} />}
                <AvatarFallback className="bg-accent text-accent-foreground text-sm font-semibold">
                  {getInitials(doc.name)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-card-foreground truncate">{doc.name}</p>
                <p className="text-xs text-primary font-medium">{doc.specialty}</p>
                <p className="text-xs text-muted-foreground truncate">{doc.hospital}</p>
                <div className="flex items-center gap-3 mt-1.5">
                  <span className="flex items-center gap-1 text-[10px] text-muted-foreground"><MapPin className="w-3 h-3" /> {doc.location}</span>
                  <span className="flex items-center gap-1 text-[10px] text-muted-foreground"><Star className="w-3 h-3 text-warning" /> {doc.rating}</span>
                  {doc.mutual > 0 && <span className="text-[10px] text-muted-foreground">{doc.mutual} mutual</span>}
                </div>
              </div>
              <div className="shrink-0 flex gap-1.5">
                <Button size="sm" className="h-8 gap-1 text-xs" onClick={() => handleAccept(doc.id)}><UserCheck className="w-3 h-3" /> Accept</Button>
                <Button size="sm" variant="outline" className="h-8 text-xs px-2" onClick={() => handleDecline(doc.id)}><X className="w-3 h-3" /></Button>
              </div>
            </div>
          </div>
        ))}

        {/* Other doctors */}
        {filtered.filter((d) => d.status !== "incoming").map((doc, i) => (
          <div
            key={doc.id}
            style={{ animationDelay: `${i * 60}ms`, animationFillMode: "backwards" }}
            className={cn(
              "glass-card rounded-xl p-4 transition-all animate-fade-in hover:scale-[1.01]",
              doc.status === "connected" && "border-success/20"
            )}
          >
            <div className="flex items-start gap-3">
              <Avatar className="w-12 h-12 shrink-0">
                {doc.avatar && <AvatarImage src={doc.avatar} />}
                <AvatarFallback className="bg-accent text-accent-foreground text-sm font-semibold">
                  {getInitials(doc.name)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-semibold text-card-foreground truncate">{doc.name}</p>
                  {doc.status === "connected" && <Check className="w-3.5 h-3.5 text-success shrink-0" />}
                </div>
                <p className="text-xs text-primary font-medium">{doc.specialty}</p>
                <p className="text-xs text-muted-foreground truncate">{doc.hospital}</p>
                <div className="flex items-center gap-3 mt-1.5">
                  <span className="flex items-center gap-1 text-[10px] text-muted-foreground"><MapPin className="w-3 h-3" /> {doc.location}</span>
                  <span className="flex items-center gap-1 text-[10px] text-muted-foreground"><Star className="w-3 h-3 text-warning" /> {doc.rating}</span>
                  {doc.mutual > 0 && <span className="text-[10px] text-muted-foreground">{doc.mutual} mutual</span>}
                </div>
              </div>
              <div className="shrink-0 flex flex-col gap-1.5">
                {doc.status === "connected" ? (
                  <Button size="sm" variant="outline" className="h-8 gap-1 text-xs"><MessageCircle className="w-3 h-3" /> Message</Button>
                ) : doc.status === "pending" ? (
                  <Button size="sm" variant="outline" className="h-8 gap-1 text-xs" onClick={() => handleCancel(doc.id)}><Clock className="w-3 h-3" /> Pending</Button>
                ) : (
                  <Button size="sm" className="h-8 gap-1 text-xs" onClick={() => handleConnect(doc.id)}><UserPlus className="w-3 h-3" /> Connect</Button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ConnectionScreen;
