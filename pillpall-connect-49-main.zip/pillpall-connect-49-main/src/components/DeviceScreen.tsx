import { useState, useEffect, useRef } from "react";
import {
  Lock,
  Unlock,
  Loader2,
  Radar,
  Pill,
  PackagePlus,
  RotateCcw,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { playLock, playSuccess, playError } from "@/lib/sounds";

const initialCompartments = [
  { slot: 1, med: "Lisinopril", loaded: true },
  { slot: 2, med: "Metformin", loaded: true },
  { slot: 3, med: "Atorvastatin", loaded: true },
  { slot: 4, med: "Amlodipine", loaded: false },
];

type Props = {
  connectBLE: () => void;
  toggleLock: () => void;
  locateDevice: () => void;
  isLocked: boolean;
  connected: boolean;
  resetAutoLock?: () => void;
  markMedicationTaken?: () => void;
};

const DeviceScreen = ({
  connectBLE,
  toggleLock,
  locateDevice,
  isLocked,
  connected,
  resetAutoLock,
  markMedicationTaken,
}: Props) => {
  const [unlocking, setUnlocking] = useState(false);
  const [compartments, setCompartments] = useState(initialCompartments);
  const [refillMode, setRefillMode] = useState(false);
  const [locating, setLocating] = useState(false);
  const [medicationChecked, setMedicationChecked] = useState(false);
  const [showTakeReminder, setShowTakeReminder] = useState(false);
  const reminderTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleToggleSlot = (slot: number) => {
    if (!refillMode) return;
    setCompartments((cs) =>
      cs.map((c) => (c.slot === slot ? { ...c, loaded: !c.loaded } : c))
    );
  };

  const handleReset = () => {
    toast.success("Device restarting — returning to home position");
  };

  const playLocateSound = () => {
    try {
      const Ctx = window.AudioContext || (window as any).webkitAudioContext;
      if (!Ctx) return;
      const ctx = new Ctx();
      const now = ctx.currentTime;

      [880, 1175, 1568].forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = "sine";
        osc.frequency.value = freq;

        const start = now + i * 0.18;

        gain.gain.setValueAtTime(0.0001, start);
        gain.gain.exponentialRampToValueAtTime(0.25, start + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.22);

        osc.connect(gain).connect(ctx.destination);
        osc.start(start);
        osc.stop(start + 0.25);
      });

      setTimeout(() => ctx.close(), 1200);
    } catch {}
  };

  // ⚠️ REMOVED FAKE AUTO-UNLOCK LOGIC
  // ESP32 should control lock state now

  const handleToggleLock = async () => {
    if (!connected) {
      playError();
      toast.error("Connect device first");
      return;
    }

    setUnlocking(true);
    playLock(isLocked);

    // Reset auto-lock timer on user interaction
    resetAutoLock?.();

    try {
      await toggleLock();
      toast.success(isLocked ? "Unlock command sent" : "Lock command sent");
    } catch {
      playError();
      toast.error("Command failed");
    }

    setTimeout(() => setUnlocking(false), 800);
  };

  const handleConfirmTaken = async () => {
    if (!connected) {
      playError();
      toast.error("Connect device first");
      return;
    }

    setMedicationChecked(true);
    setUnlocking(true);
    resetAutoLock?.();
    markMedicationTaken?.();
    playLock(isLocked);

    try {
      await toggleLock();
      toast.success("Medication recorded and device relocked");
    } catch {
      playError();
      toast.error("Command failed");
    }

    setTimeout(() => setUnlocking(false), 800);
  };

  useEffect(() => {
    if (!isLocked) {
      setShowTakeReminder(false);
      if (reminderTimerRef.current) {
        clearTimeout(reminderTimerRef.current);
      }
      reminderTimerRef.current = setTimeout(() => {
        setShowTakeReminder(true);
      }, 10000);
    } else {
      setShowTakeReminder(false);
      setMedicationChecked(false);
    }

    return () => {
      if (reminderTimerRef.current) {
        clearTimeout(reminderTimerRef.current);
      }
    };
  }, [isLocked]);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-semibold text-foreground">Device</h2>
        <p className="text-xs text-muted-foreground">
          Manage and control your PillPall device
        </p>
      </div>

      {/* LOCK CONTROL */}
      <div
        className={cn(
          "rounded-2xl p-6 space-y-5 border transition-all duration-500",
          isLocked ? "glass-card" : "bg-success/10 border-success/30"
        )}
      >
        <div className="flex flex-col items-center text-center gap-3">
          <div
            className={cn(
              "w-20 h-20 rounded-2xl flex items-center justify-center transition-all duration-500",
              isLocked ? "gradient-primary" : "bg-success/20",
              unlocking && "animate-ring-pulse"
            )}
          >
            {isLocked ? (
              <Lock className="w-10 h-10 text-primary-foreground" />
            ) : (
              <Unlock className="w-10 h-10 text-success" />
            )}
          </div>

          <div>
            <p className="text-base font-semibold text-card-foreground">
              {unlocking
                ? "Processing…"
                : isLocked
                ? "Device is locked"
                : "Device is unlocked"}
            </p>

            <div className="overflow-hidden">
              <p
                className="text-sm font-medium text-warning transition-all duration-500"
                style={{
                  transform: showTakeReminder ? "translateY(0)" : "translateY(12px)",
                  opacity: showTakeReminder ? 1 : 0,
                }}
              >
                Take your medicine now
              </p>
            </div>

            <p className="text-xs text-muted-foreground mt-1">
              {isLocked
                ? "Tap to unlock compartments"
                : "Tick the box once medication is taken"}
            </p>
          </div>
        </div>

        {isLocked ? (
          <Button
            onClick={handleToggleLock}
            disabled={unlocking || !connected}
            size="lg"
            className="w-full h-12 text-base"
            variant="default"
          >
            {unlocking ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Sending…
              </>
            ) : (
              <>
                <Unlock className="w-5 h-5" />
                Unlock Device
              </>
            )}
          </Button>
        ) : (
          <label className="w-full flex items-center gap-3 rounded-2xl border border-success/30 bg-success/10 px-4 py-3 cursor-pointer">
            <input
              type="checkbox"
              checked={medicationChecked}
              onChange={handleConfirmTaken}
              disabled={unlocking || !connected}
              className="h-5 w-5 rounded border border-success text-success focus:ring-primary"
            />
            <div className="flex-1">
              <p className="font-semibold text-card-foreground">Medication taken</p>
              <p className="text-xs text-muted-foreground">This will relock your device</p>
            </div>
            {unlocking && <Loader2 className="w-5 h-5 animate-spin text-success" />}
          </label>
        )}

        {/* CONNECT BUTTON (only if not connected) */}
        {!connected && (
          <Button
            onClick={connectBLE}
            variant="secondary"
            className="w-full"
          >
            Connect to Device
          </Button>
        )}
      </div>

      {/* STATUS */}

      {/* COMPARTMENTS */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-foreground">
            Compartments
          </h3>

          {refillMode && (
            <span className="text-[10px] font-semibold text-primary uppercase tracking-wide">
              Tap slots to refill
            </span>
          )}
        </div>

        <div className="grid grid-cols-2 gap-2">
          {compartments.map((c, i) => (
            <button
              key={c.slot}
              onClick={() => handleToggleSlot(c.slot)}
              disabled={!refillMode}
              className={cn(
                "glass-card rounded-xl p-4 space-y-2 text-left transition-all duration-300",
                refillMode &&
                  "hover:border-primary/50 hover:scale-[1.02] cursor-pointer"
              )}
            >
              <span className="text-xs text-muted-foreground">
                Slot {c.slot}
              </span>

              <div className="flex items-center gap-2">
                <Pill className="w-4 h-4 text-primary" />
                <p className="text-sm font-semibold">{c.med}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* ACTIONS */}
      <div className="space-y-2">
        <Button
          variant="outline"
          className={cn(
            "w-full h-11 relative",
            locating && "bg-primary/10 border-primary"
          )}
          onClick={async () => {
            if (!connected) {
              playError();
              toast.error("Connect device first");
              return;
            }

            setLocating(true);
            playLocateSound();

            try {
              await locateDevice();
              playSuccess();
              toast.success("Locating device…");
            } catch {
              playError();
              toast.error("Locate command failed");
            }

            setTimeout(() => setLocating(false), 2000);
          }}
        >
          {locating && (
            <span className="absolute inset-0 rounded-lg animate-ping bg-primary/30" />
          )}
          <Radar className={cn("w-4 h-4 mr-2", locating && "animate-pulse")} />
          {locating ? "Locating…" : "Locate Device"}
        </Button>

        <Button
          variant={refillMode ? "default" : "outline"}
          className="w-full h-11"
          onClick={() => {
            setRefillMode((r) => {
              const next = !r;
              toast(next ? "Refill mode enabled" : "Refill mode disabled");
              return next;
            });
          }}
        >
          <PackagePlus className="w-4 h-4" />
          {refillMode ? "Exit Refill Mode" : "Refill Mode"}
        </Button>

        <Button
          variant="outline"
          className="w-full h-11"
          onClick={handleReset}
        >
          <RotateCcw className="w-4 h-4" />
          Recenter Device
        </Button>
      </div>
    </div>
  );
};

export default DeviceScreen;