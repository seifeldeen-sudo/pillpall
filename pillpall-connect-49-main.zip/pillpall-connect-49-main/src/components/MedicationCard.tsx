import { Clock, Pill } from "lucide-react";
import { cn } from "@/lib/utils";

interface MedicationCardProps {
  name: string;
  dosage: string;
  time: string;
  status: "upcoming" | "taken" | "missed";
  compartment: number;
}

const MedicationCard = ({ name, dosage, time, status, compartment }: MedicationCardProps) => {
  const statusConfig = {
    upcoming: { label: "Upcoming", dotClass: "bg-warning" },
    taken: { label: "Taken", dotClass: "bg-success" },
    missed: { label: "Missed", dotClass: "bg-destructive" },
  };

  const { label, dotClass } = statusConfig[status];

  return (
    <div className={cn(
      "glass-card rounded-xl p-4 flex items-center justify-between transition-all hover:shadow-md",
      status === "upcoming" && "border-l-4 border-l-warning",
      status === "taken" && "border-l-4 border-l-success opacity-70",
      status === "missed" && "border-l-4 border-l-destructive"
    )}>
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-accent flex items-center justify-center">
          <Pill className="w-5 h-5 text-accent-foreground" />
        </div>
        <div>
          <p className="font-medium text-card-foreground">{name}</p>
          <p className="text-xs text-muted-foreground">{dosage} · Slot {compartment}</p>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <div className="text-right">
          <div className="flex items-center gap-1.5">
            <div className={cn("w-2 h-2 rounded-full", dotClass)} />
            <span className="text-xs text-muted-foreground">{label}</span>
          </div>
          <div className="flex items-center gap-1 text-sm text-card-foreground font-medium">
            <Clock className="w-3 h-3" />
            {time}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MedicationCard;
