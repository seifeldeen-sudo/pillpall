import { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";

interface TimeWheelPickerProps {
  hour: number; // 1-12
  minute: number; // 0-59
  period: "AM" | "PM";
  onChange: (h: number, m: number, p: "AM" | "PM") => void;
}

const ITEM_HEIGHT = 36;
const VISIBLE = 5; // odd

const Wheel = <T,>({
  items,
  value,
  onChange,
  format,
}: {
  items: T[];
  value: T;
  onChange: (v: T) => void;
  format: (v: T) => string;
}) => {
  const ref = useRef<HTMLDivElement>(null);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const idx = items.indexOf(value);
    if (idx >= 0) el.scrollTop = idx * ITEM_HEIGHT;
  }, []); // initial only

  const handleScroll = () => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => {
      const el = ref.current;
      if (!el) return;
      const idx = Math.round(el.scrollTop / ITEM_HEIGHT);
      const clamped = Math.max(0, Math.min(items.length - 1, idx));
      el.scrollTo({ top: clamped * ITEM_HEIGHT, behavior: "smooth" });
      if (items[clamped] !== value) onChange(items[clamped]);
    }, 100);
  };

  const padding = ((VISIBLE - 1) / 2) * ITEM_HEIGHT;

  return (
    <div
      ref={ref}
      onScroll={handleScroll}
      className="flex-1 overflow-y-auto snap-y snap-mandatory scrollbar-none"
      style={{
        height: VISIBLE * ITEM_HEIGHT,
        scrollbarWidth: "none",
      }}
    >
      <div style={{ paddingTop: padding, paddingBottom: padding }}>
        {items.map((item, i) => (
          <div
            key={i}
            onClick={() => {
              const el = ref.current;
              if (el) el.scrollTo({ top: i * ITEM_HEIGHT, behavior: "smooth" });
            }}
            className={cn(
              "snap-center flex items-center justify-center text-base font-medium transition-all cursor-pointer",
              item === value ? "text-foreground" : "text-muted-foreground/50"
            )}
            style={{ height: ITEM_HEIGHT }}
          >
            {format(item)}
          </div>
        ))}
      </div>
    </div>
  );
};

const TimeWheelPicker = ({ hour, minute, period, onChange }: TimeWheelPickerProps) => {
  const hours = Array.from({ length: 12 }, (_, i) => i + 1);
  const minutes = Array.from({ length: 60 }, (_, i) => i);
  const periods: ("AM" | "PM")[] = ["AM", "PM"];

  return (
    <div className="relative bg-accent/30 rounded-xl overflow-hidden border border-border">
      {/* Selection highlight */}
      <div
        className="absolute left-0 right-0 pointer-events-none bg-primary/10 border-y border-primary/30"
        style={{
          top: ((VISIBLE - 1) / 2) * ITEM_HEIGHT,
          height: ITEM_HEIGHT,
        }}
      />
      <div className="flex">
        <Wheel
          items={hours}
          value={hour}
          onChange={(v) => onChange(v, minute, period)}
          format={(v) => String(v)}
        />
        <Wheel
          items={minutes}
          value={minute}
          onChange={(v) => onChange(hour, v, period)}
          format={(v) => String(v).padStart(2, "0")}
        />
        <Wheel
          items={periods}
          value={period}
          onChange={(v) => onChange(hour, minute, v)}
          format={(v) => v}
        />
      </div>
    </div>
  );
};

export default TimeWheelPicker;
