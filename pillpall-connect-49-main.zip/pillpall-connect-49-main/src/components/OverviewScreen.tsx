import { Dispatch, SetStateAction, useState } from "react";
import DeviceStatusCard from "./DeviceStatusCard";
import MedicationCard from "./MedicationCard";
import { Hospital, MapPin, Navigation, Plus, Pencil, X, Pill } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import TimeWheelPicker from "./TimeWheelPicker";

const parseTime = (t: string): { h: number; m: number; p: "AM" | "PM" } => {
  const match = t.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
  if (!match) return { h: 8, m: 0, p: "AM" };
  return { h: Number(match[1]), m: Number(match[2]), p: match[3].toUpperCase() as "AM" | "PM" };
};

const formatTime = (h: number, m: number, p: "AM" | "PM") =>
  `${h}:${String(m).padStart(2, "0")} ${p}`;

const connectedHospitals = [
  { name: "St. Mary's General Hospital", dept: "Cardiology", lastSync: "2 min ago" },
];

interface Medication {
  name: string;
  dosage: string;
  time: string;
  status: "upcoming" | "taken" | "missed";
  compartment: number;
}

type OverviewScreenProps = {
  medications: Medication[];
  setMedications: Dispatch<SetStateAction<Medication[]>>;
};

const OverviewScreen = ({ medications, setMedications }: OverviewScreenProps) => {
  const [showForm, setShowForm] = useState(false);
  const [editIndex, setEditIndex] = useState<number | null>(null);
  const [formData, setFormData] = useState({ name: "", dosage: "", time: "8:00 AM", compartment: "" });

  const openAdd = () => {
    setEditIndex(null);
    setFormData({ name: "", dosage: "", time: "8:00 AM", compartment: "" });
    setShowForm(true);
  };

  const openEdit = (i: number) => {
    const med = medications[i];
    setEditIndex(i);
    setFormData({ name: med.name, dosage: med.dosage, time: med.time, compartment: String(med.compartment) });
    setShowForm(true);
  };

  const handleSave = () => {
    if (!formData.name.trim() || !formData.dosage.trim() || !formData.time.trim()) {
      toast.error("Please fill in all fields");
      return;
    }
    const med: Medication = {
      name: formData.name,
      dosage: formData.dosage,
      time: formData.time,
      status: "upcoming",
      compartment: Number(formData.compartment) || medications.length + 1,
    };
    if (editIndex !== null) {
      const updated = [...medications];
      updated[editIndex] = { ...med, status: medications[editIndex].status };
      setMedications(updated);
      toast.success("Medication updated");
    } else {
      setMedications([...medications, med]);
      toast.success("Medication added");
    }
    setShowForm(false);
  };

  const handleRemove = (i: number) => {
    setMedications(medications.filter((_, idx) => idx !== i));
    toast("Medication removed");
  };

  const remaining = medications.filter((m) => m.status === "upcoming").length;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-semibold text-foreground">Overview</h2>
      </div>

      <DeviceStatusCard
        connected={true}
        batteryLevel={78}
        withYou={true}
        lastSync="2 min ago"
      />

      {/* Device Location */}
      <div className="glass-card rounded-xl p-5 animate-fade-in" style={{ animationDelay: "60ms", animationFillMode: "backwards" }}>
        <div className="flex items-center gap-2 mb-3">
          <Navigation className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-semibold text-card-foreground">Device Status</h3>
        </div>
        <div className="rounded-lg bg-accent/50 p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg gradient-primary flex items-center justify-center shrink-0">
            <MapPin className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <p className="text-sm font-medium text-card-foreground">Currently with you</p>
            <p className="text-xs text-muted-foreground">Last GPS: Home (12 Oak Street)</p>
            <p className="text-xs text-muted-foreground">Last checked: 5 min ago</p>
          </div>
        </div>
      </div>

      {/* Connected Hospital */}
      <div className="glass-card rounded-xl p-5 animate-fade-in" style={{ animationDelay: "120ms", animationFillMode: "backwards" }}>
        <div className="flex items-center gap-2 mb-3">
          <Hospital className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-semibold text-card-foreground">Connected Hospitals</h3>
        </div>
        <div className="space-y-2">
          {connectedHospitals.map((h) => (
            <div key={h.name} className="rounded-lg border border-success/20 bg-success/5 p-3 flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-card-foreground">{h.name}</p>
                <p className="text-xs text-muted-foreground">{h.dept} · Synced {h.lastSync}</p>
              </div>
              <div className="w-2.5 h-2.5 rounded-full bg-success pulse-dot" />
            </div>
          ))}
        </div>
      </div>

      {/* Medications */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-foreground">Today's Medications</h3>
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">{medications.length} doses · {remaining} remaining</span>
            <Button size="sm" variant="outline" className="h-7 gap-1 text-xs" onClick={openAdd}>
              <Plus className="w-3 h-3" /> Add
            </Button>
          </div>
        </div>

        {/* Add/Edit Form */}
        {showForm && (
          <div className="glass-card rounded-xl p-4 mb-3 space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-sm font-semibold text-card-foreground">
                {editIndex !== null ? "Edit Medication" : "Add Medication"}
              </p>
              <button onClick={() => setShowForm(false)} className="text-muted-foreground hover:text-foreground">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <input
                placeholder="Name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-accent/50 border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary/50"
              />
              <input
                placeholder="Dosage (e.g. 10mg)"
                value={formData.dosage}
                onChange={(e) => setFormData({ ...formData, dosage: e.target.value })}
                className="bg-accent/50 border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary/50"
              />
              <input
                placeholder="Slot #"
                value={formData.compartment}
                onChange={(e) => setFormData({ ...formData, compartment: e.target.value })}
                className="bg-accent/50 border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary/50 col-span-2"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-muted-foreground px-1">Time</label>
              {(() => {
                const { h, m, p } = parseTime(formData.time);
                return (
                  <TimeWheelPicker
                    hour={h}
                    minute={m}
                    period={p}
                    onChange={(nh, nm, np) =>
                      setFormData({ ...formData, time: formatTime(nh, nm, np) })
                    }
                  />
                );
              })()}
            </div>
            <Button size="sm" onClick={handleSave} className="w-full">
              {editIndex !== null ? "Save Changes" : "Add Medication"}
            </Button>
          </div>
        )}

        <div className="space-y-2">
          {medications.map((med, i) => (
            <div
              key={`${med.name}-${i}`}
              className="relative group animate-fade-in transition-transform hover:scale-[1.01]"
              style={{ animationDelay: `${i * 60}ms`, animationFillMode: "backwards" }}
            >
              <MedicationCard {...med} />
              <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                <button
                  onClick={() => openEdit(i)}
                  className="w-7 h-7 rounded-lg bg-accent/80 backdrop-blur flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
                >
                  <Pencil className="w-3 h-3" />
                </button>
                <button
                  onClick={() => handleRemove(i)}
                  className="w-7 h-7 rounded-lg bg-destructive/10 backdrop-blur flex items-center justify-center text-destructive hover:bg-destructive/20 transition-colors"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default OverviewScreen;
