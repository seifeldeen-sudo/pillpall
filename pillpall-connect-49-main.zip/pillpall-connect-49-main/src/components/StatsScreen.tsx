import { TrendingUp, CheckCircle, AlertCircle, Clock } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts";

const adherenceData = [
  { day: "Mon", rate: 100 },
  { day: "Tue", rate: 85 },
  { day: "Wed", rate: 100 },
  { day: "Thu", rate: 70 },
  { day: "Fri", rate: 100 },
  { day: "Sat", rate: 90 },
  { day: "Sun", rate: 95 },
];

const weeklyData = [
  { week: "W1", taken: 18, missed: 3 },
  { week: "W2", taken: 20, missed: 1 },
  { week: "W3", taken: 19, missed: 2 },
  { week: "W4", taken: 21, missed: 0 },
];

const stats = [
  { icon: CheckCircle, label: "Adherence Rate", value: "92%", change: "+3%", positive: true },
  { icon: TrendingUp, label: "Streak", value: "14 days", change: "Best: 21", positive: true },
  { icon: AlertCircle, label: "Missed Doses", value: "2", change: "This week", positive: false },
  { icon: Clock, label: "Avg. Delay", value: "4 min", change: "-2 min", positive: true },
];

const StatsScreen = () => {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-semibold text-foreground">Medication Stats</h2>
        <p className="text-sm text-muted-foreground">Your adherence overview for the past 30 days</p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {stats.map((stat, i) => (
          <div
            key={stat.label}
            className="glass-card rounded-xl p-4 animate-fade-in transition-transform hover:scale-[1.02]"
            style={{ animationDelay: `${i * 60}ms`, animationFillMode: "backwards" }}
          >
            <div className="flex items-center gap-2 mb-2">
              <stat.icon className="w-4 h-4 text-primary" />
              <span className="text-xs text-muted-foreground">{stat.label}</span>
            </div>
            <p className="text-2xl font-bold text-card-foreground">{stat.value}</p>
            <p className={cn("text-xs mt-1", stat.positive ? "text-success" : "text-warning")}>
              {stat.change}
            </p>
          </div>
        ))}
      </div>

      <div className="glass-card rounded-xl p-5 animate-fade-in" style={{ animationDelay: "260ms", animationFillMode: "backwards" }}>
        <h3 className="text-sm font-semibold text-card-foreground mb-4">Daily Adherence Rate</h3>
        <ResponsiveContainer width="100%" height={180}>
          <AreaChart data={adherenceData}>
            <defs>
              <linearGradient id="adherenceGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(199, 89%, 48%)" stopOpacity={0.3} />
                <stop offset="95%" stopColor="hsl(199, 89%, 48%)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(210, 18%, 90%)" />
            <XAxis dataKey="day" tick={{ fontSize: 12, fill: 'hsl(215, 15%, 50%)' }} />
            <YAxis domain={[0, 100]} tick={{ fontSize: 12, fill: 'hsl(215, 15%, 50%)' }} />
            <Tooltip />
            <Area type="monotone" dataKey="rate" stroke="hsl(199, 89%, 48%)" fill="url(#adherenceGrad)" strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="glass-card rounded-xl p-5 animate-fade-in" style={{ animationDelay: "340ms", animationFillMode: "backwards" }}>
        <h3 className="text-sm font-semibold text-card-foreground mb-4">Weekly Breakdown</h3>
        <ResponsiveContainer width="100%" height={160}>
          <BarChart data={weeklyData}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(210, 18%, 90%)" />
            <XAxis dataKey="week" tick={{ fontSize: 12, fill: 'hsl(215, 15%, 50%)' }} />
            <YAxis tick={{ fontSize: 12, fill: 'hsl(215, 15%, 50%)' }} />
            <Tooltip />
            <Bar dataKey="taken" fill="hsl(168, 60%, 46%)" radius={[4, 4, 0, 0]} />
            <Bar dataKey="missed" fill="hsl(0, 72%, 55%)" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

function cn(...classes: (string | boolean | undefined)[]) {
  return classes.filter(Boolean).join(" ");
}

export default StatsScreen;
