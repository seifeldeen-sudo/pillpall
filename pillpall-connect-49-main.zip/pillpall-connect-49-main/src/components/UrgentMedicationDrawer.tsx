import { AlertTriangle, Clock, Pill, X } from "lucide-react";
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
} from "@/components/ui/drawer";
import { Button } from "@/components/ui/button";

interface UrgentMedicationDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAcknowledge: () => void;
  onSnooze: () => void;
}

const UrgentMedicationDrawer = ({
  open,
  onOpenChange,
  onAcknowledge,
  onSnooze,
}: UrgentMedicationDrawerProps) => {
  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <DrawerContent className="border-t-4 border-t-destructive">
        <DrawerHeader className="text-center">
          <div className="mx-auto mb-2 w-14 h-14 rounded-full bg-destructive/10 flex items-center justify-center animate-pulse">
            <AlertTriangle className="w-7 h-7 text-destructive" />
          </div>
          <DrawerTitle className="text-xl text-destructive">
            Urgent Medication Due
          </DrawerTitle>
          <DrawerDescription>
            You have a time-critical medication that must be taken now.
          </DrawerDescription>
        </DrawerHeader>

        <div className="px-6 pb-2">
          <div className="rounded-xl border border-destructive/20 bg-destructive/5 p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-destructive/10 flex items-center justify-center shrink-0">
              <Pill className="w-6 h-6 text-destructive" />
            </div>
            <div className="flex-1">
              <p className="font-semibold text-card-foreground">Warfarin</p>
              <p className="text-sm text-muted-foreground">5mg · Slot 2</p>
            </div>
            <div className="text-right">
              <div className="flex items-center gap-1 text-sm font-semibold text-destructive">
                <Clock className="w-3.5 h-3.5" />
                6:00 PM
              </div>
              <p className="text-xs text-destructive/70 font-medium">15 min overdue</p>
            </div>
          </div>

          <p className="mt-4 text-xs text-muted-foreground text-center leading-relaxed">
            Missing this dose may affect your treatment. If you are unable to take it, contact your healthcare provider immediately.
          </p>
        </div>

        <DrawerFooter className="gap-2">
          <Button
            onClick={onAcknowledge}
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90 h-12 text-base font-semibold"
          >
            Mark as Taken
          </Button>
          <Button
            variant="outline"
            onClick={onSnooze}
            className="h-11"
          >
            Remind Me in 5 Minutes
          </Button>
          <DrawerClose asChild>
            <Button variant="ghost" size="sm" className="text-muted-foreground">
              Dismiss
            </Button>
          </DrawerClose>
        </DrawerFooter>
      </DrawerContent>
    </Drawer>
  );
};

export default UrgentMedicationDrawer;
