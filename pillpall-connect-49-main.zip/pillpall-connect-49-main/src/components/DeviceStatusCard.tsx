import { Bluetooth, Wifi, MapPin, Battery } from "lucide-react";
import { cn } from "@/lib/utils";

interface DeviceStatusCardProps {
  connected: boolean;
  batteryLevel: number;
  withYou: boolean;
  lastSync: string;
}

const DeviceStatusCard = ({ connected, batteryLevel, withYou, lastSync }: DeviceStatusCardProps) => {
  return (
    <div className="glass-card rounded-2xl p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className={cn(
            "w-12 h-12 rounded-xl flex items-center justify-center",
            connected ? "gradient-primary" : "bg-muted"
          )}>
            <Bluetooth className={cn("w-6 h-6", connected ? "text-primary-foreground" : "text-muted-foreground")} />
          </div>
          <div>
            <h3 className="font-semibold text-card-foreground">PillPall Device</h3>
            <p className="text-sm text-muted-foreground">Serial: PP-2024-0847</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className={cn(
            "w-2.5 h-2.5 rounded-full",
            connected ? "bg-success pulse-dot" : "bg-destructive"
          )} />
          <span className={cn(
            "text-sm font-medium",
            connected ? "text-success" : "text-destructive"
          )}>
            {connected ? "Connected" : "Disconnected"}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4 pt-2">
        <div className="flex items-center gap-2">
          <div className="relative w-5 h-3" aria-hidden="true">
            {/* Battery body */}
            <div className="absolute inset-0 rounded-[3px] border border-muted-foreground/70 overflow-hidden">
              <div
                className={cn(
                  "h-full transition-all",
                  batteryLevel > 50
                    ? "bg-success"
                    : batteryLevel > 20
                    ? "bg-warning"
                    : "bg-destructive"
                )}
                style={{ width: `${Math.max(0, Math.min(100, batteryLevel))}%` }}
              />
            </div>
            {/* Battery cap */}
            <div className="absolute -right-1 top-1/2 -translate-y-1/2 w-[2px] h-1.5 rounded-r-sm bg-muted-foreground/70" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Battery</p>
            <p className="text-sm font-semibold text-card-foreground">{batteryLevel}%</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <MapPin className="w-4 h-4 text-muted-foreground" />
          <div>
            <p className="text-xs text-muted-foreground">With You</p>
            <p className={cn("text-sm font-semibold", withYou ? "text-success" : "text-destructive")}>{withYou ? "Yes" : "No"}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Wifi className="w-4 h-4 text-muted-foreground" />
          <div>
            <p className="text-xs text-muted-foreground">Last Sync</p>
            <p className="text-sm font-semibold text-card-foreground">{lastSync}</p>
          </div>
        </div>
      </div>

    </div>
  );
};

export default DeviceStatusCard;
