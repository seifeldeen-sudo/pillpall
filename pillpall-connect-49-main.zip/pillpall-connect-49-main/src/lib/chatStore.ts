import { useSyncExternalStore } from "react";

export interface ChatMessage {
  id: number;
  from: "dr" | "you";
  text: string;
  time: string;
}

export interface Chat {
  id: string;
  doctorName: string;
  specialty: string;
  hospital: string;
  messages: ChatMessage[];
}

const initialChats: Chat[] = [
  {
    id: "chen",
    doctorName: "Dr. Sarah Chen",
    specialty: "Cardiologist",
    hospital: "St. Mary's",
    messages: [
      { id: 1, from: "dr", text: "Your blood pressure readings look stable this week. Keep up the good work!", time: "Today, 10:32 AM" },
      { id: 2, from: "you", text: "Thank you! Should I continue with the same Lisinopril dosage?", time: "Today, 10:45 AM" },
      { id: 3, from: "dr", text: "Yes, stay on 10mg. I'll review again after your next check-up on the 15th.", time: "Today, 11:02 AM" },
    ],
  },
];

let chats: Chat[] = [...initialChats];
const listeners = new Set<() => void>();

const emit = () => listeners.forEach((l) => l());

export const chatStore = {
  subscribe(cb: () => void) {
    listeners.add(cb);
    return () => listeners.delete(cb);
  },
  getSnapshot() {
    return chats;
  },
  addChat(chat: Omit<Chat, "messages"> & { greeting?: string }) {
    if (chats.some((c) => c.id === chat.id)) return;
    const greeting: ChatMessage = {
      id: Date.now(),
      from: "dr",
      text: chat.greeting ?? `Hi, I'm ${chat.doctorName}. Thanks for connecting — let me know how I can help.`,
      time: "Just now",
    };
    chats = [...chats, { id: chat.id, doctorName: chat.doctorName, specialty: chat.specialty, hospital: chat.hospital, messages: [greeting] }];
    emit();
  },
  sendMessage(chatId: string, text: string) {
    chats = chats.map((c) =>
      c.id === chatId
        ? { ...c, messages: [...c.messages, { id: Date.now(), from: "you", text, time: "Just now" }] }
        : c
    );
    emit();
  },
};

export const useChats = () =>
  useSyncExternalStore(chatStore.subscribe, chatStore.getSnapshot, chatStore.getSnapshot);
