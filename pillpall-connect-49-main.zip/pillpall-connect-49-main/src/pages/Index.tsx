import { useState, useEffect } from "react";
import {
  LayoutDashboard,
  BarChart3,
  Link2,
  Pill,
  MessageCircle,
  Smartphone,
} from "lucide-react";

import { toast } from "sonner";
import { cn } from "@/lib/utils";

import OverviewScreen from "@/components/OverviewScreen";
import StatsScreen from "@/components/StatsScreen";
import ConnectionScreen from "@/components/ConnectionScreen";
import DoctorCommsScreen from "@/components/DoctorCommsScreen";
import DeviceScreen from "@/components/DeviceScreen";
import UrgentMedicationDrawer from "@/components/UrgentMedicationDrawer";

type Tab =
  | "overview"
  | "device"
  | "stats"
  | "messages"
  | "connect";

const tabs: {
  id: Tab;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}[] = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "device", label: "Device", icon: Smartphone },
  { id: "stats", label: "Stats", icon: BarChart3 },
  { id: "messages", label: "Messages", icon: MessageCircle },
  { id: "connect", label: "Connect", icon: Link2 },
];

// ===== BLE PROPS FROM APP =====
type BLEProps = {
  connectBLE: () => void;
  toggleLock: () => void;
  locateDevice: () => void;
  isLocked: boolean;
  connected: boolean;
  resetAutoLock?: () => void;
};

type Medication = {
  name: string;
  dosage: string;
  time: string;
  status: "upcoming" | "taken" | "missed";
  compartment: number;
};

const defaultMedications: Medication[] = [
  { name: "Lisinopril", dosage: "10mg", time: "8:00 AM", status: "taken", compartment: 1 },
  { name: "Metformin", dosage: "500mg", time: "12:00 PM", status: "taken", compartment: 2 },
  { name: "Atorvastatin", dosage: "20mg", time: "6:00 PM", status: "upcoming", compartment: 3 },
  { name: "Amlodipine", dosage: "5mg", time: "9:00 PM", status: "upcoming", compartment: 4 },
];

type Props = {
  ble: BLEProps;
};

const Index = ({ ble }: Props) => {
  const [activeTab, setActiveTab] = useState<Tab>("overview");
  const [urgentDrawerOpen, setUrgentDrawerOpen] = useState(false);
  const [medications, setMedications] = useState<Medication[]>(defaultMedications);

  const parseTime = (t: string): { h: number; m: number; p: "AM" | "PM" } => {
    const match = t.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
    if (!match) return { h: 8, m: 0, p: "AM" };
    return { h: Number(match[1]), m: Number(match[2]), p: match[3].toUpperCase() as "AM" | "PM" };
  };

  const getScheduledToday = (time: string, now: Date) => {
    const { h, m, p } = parseTime(time);
    const scheduled = new Date(now);
    let hour = h % 12;
    if (p === "PM") hour += 12;
    scheduled.setHours(hour, m, 0, 0);
    return scheduled;
  };

  const markDueMedicationTaken = () => {
    setMedications((prev) => {
      const now = new Date();
      const dueIndex = prev.findIndex(
        (med) =>
          med.status === "upcoming" &&
          getScheduledToday(med.time, now).getTime() <= now.getTime()
      );
      if (dueIndex === -1) return prev;
      const next = [...prev];
      next[dueIndex] = { ...next[dueIndex], status: "taken" };
      return next;
    });
  };

  useEffect(() => {
    const timer = setTimeout(() => setUrgentDrawerOpen(true), 3000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-screen bg-background flex flex-col max-w-md mx-auto">
      {/* HEADER */}
      <header className="px-5 pt-6 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center">
            <Pill className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground">PillPall</h1>
            <p className="text-xs text-muted-foreground">
              Smart Medication Management
            </p>
          </div>
        </div>
      </header>

      {/* MAIN CONTENT */}
      <main className="flex-1 px-5 pb-24 overflow-y-auto">
        <div className="animate-fade-in">
          {activeTab === "overview" && (
            <OverviewScreen
              medications={medications}
              setMedications={setMedications}
            />
          )}

          {activeTab === "device" && (
            <DeviceScreen
              connectBLE={ble.connectBLE}
              toggleLock={ble.toggleLock}
              locateDevice={ble.locateDevice}
              isLocked={ble.isLocked}
              connected={ble.connected}
              resetAutoLock={ble.resetAutoLock}
              markMedicationTaken={markDueMedicationTaken}
            />
          )}

          {activeTab === "stats" && <StatsScreen />}
          {activeTab === "messages" && <DoctorCommsScreen />}
          {activeTab === "connect" && <ConnectionScreen />}
        </div>
      </main>

      {/* URGENT DRAWER */}
      <UrgentMedicationDrawer
        open={urgentDrawerOpen}
        onOpenChange={setUrgentDrawerOpen}
        onAcknowledge={() => {
          setUrgentDrawerOpen(false);
          toast.success("Medication marked as taken");
        }}
        onSnooze={() => {
          setUrgentDrawerOpen(false);
          toast("Reminder set for 5 minutes");
          setTimeout(() => setUrgentDrawerOpen(true), 300000);
        }}
      />

      {/* BOTTOM NAV */}
      <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md bg-card/90 backdrop-blur-lg border-t border-border px-6 py-2 z-50">
        <div className="flex items-center justify-around">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                "flex flex-col items-center gap-1 py-2 px-2 rounded-xl transition-colors",
                activeTab === tab.id
                  ? "text-primary"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <tab.icon className="w-5 h-5" />
              <span className="text-[11px] font-medium">{tab.label}</span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
};

export default Index;