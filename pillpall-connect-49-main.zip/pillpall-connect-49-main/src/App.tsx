
import { useState, useEffect, useRef, useCallback } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

import Index from "./pages/Index.tsx";
import NotFound from "./pages/NotFound.tsx";
// ===== WEB BLUETOOTH TYPE DECLARATIONS =====
declare global {
  interface Navigator {
    bluetooth: Bluetooth;
  }
}

interface Bluetooth {
  requestDevice(options: BluetoothRequestDeviceOptions): Promise<BluetoothDevice>;
}

interface BluetoothRequestDeviceOptions {
  filters?: BluetoothLEScanFilter[];
  optionalServices?: BluetoothServiceUUID[];
}

interface BluetoothLEScanFilter {
  name?: string;
  services?: BluetoothServiceUUID[];
}

type BluetoothServiceUUID = string;

interface BluetoothDevice {
  gatt?: BluetoothRemoteGATTServer;
}

interface BluetoothRemoteGATTServer {
  device: BluetoothDevice;
  connect(): Promise<BluetoothRemoteGATTServer>;
  disconnect(): void;
  getPrimaryService(service: BluetoothServiceUUID): Promise<BluetoothRemoteGATTService>;
}

interface BluetoothRemoteGATTService {
  device: BluetoothDevice;
  uuid: string;
  getCharacteristic(characteristic: BluetoothServiceUUID): Promise<BluetoothRemoteGATTCharacteristic>;
}

interface BluetoothRemoteGATTCharacteristic {
  service: BluetoothRemoteGATTService;
  uuid: string;
  writeValue(value: BufferSource): Promise<void>;
  readValue(): Promise<DataView>;
  startNotifications(): Promise<BluetoothRemoteGATTCharacteristic>;
  addEventListener(type: string, callback: EventListener): void;
}
const queryClient = new QueryClient();

// ===== BLE CONFIG =====
const SERVICE_UUID = "12345678-1234-1234-1234-123456789abc";
const CHARACTERISTIC_UUID = "abcd1234-1234-1234-1234-123456789abc";

const App = () => {
  const [characteristic, setCharacteristic] =
    useState<BluetoothRemoteGATTCharacteristic | null>(null);

  const [isLocked, setIsLocked] = useState(true);
  const [connected, setConnected] = useState(false);

  // 🔌 CONNECT TO ESP32
  async function connectBLE() {
    try {
      const device = await navigator.bluetooth.requestDevice({
        filters: [{ name: "ESP32_LOCK" }],
        optionalServices: [SERVICE_UUID],
      });

      const server = await device.gatt!.connect();
      const service = await server.getPrimaryService(SERVICE_UUID);
      const char = await service.getCharacteristic(CHARACTERISTIC_UUID);

      setCharacteristic(char);
      setConnected(true);

      console.log("BLE connected");
    } catch (err) {
      console.error("BLE connect failed:", err);
    }
  }

  // 🔓 TOGGLE LOCK
  async function toggleLock() {
    if (!characteristic) {
      console.log("Not connected");
      return;
    }

    try {
      const data = new TextEncoder().encode("toggle");
      await characteristic.writeValue(data);

      setIsLocked((prev) => !prev);
    } catch (err) {
      console.error("Toggle failed:", err);
    }
  }

  // 📍 LOCATE DEVICE (Morse code !)
  async function locateDevice() {
    if (!characteristic) {
      console.log("Not connected");
      return;
    }

    try {
      const data = new TextEncoder().encode("locate");
      await characteristic.writeValue(data);
      console.log("Locate command sent");
    } catch (err) {
      console.error("Locate failed:", err);
    }
  }

  // ⏱️ AUTO-LOCK AFTER 30 SECONDS OF INACTIVITY
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const resetAutoLockTimer = useCallback(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }
    if (connected) {
      timerRef.current = setTimeout(() => {
        console.log("Auto-lock triggered after 30s");
        toggleLock();
      }, 30000);
    }
  }, [connected, characteristic]);

  // Start timer on connect, reset on any interaction
  useEffect(() => {
    if (connected) {
      resetAutoLockTimer();
    }
    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, [connected, resetAutoLockTimer]);

  // Reset timer on user interaction
  const handleUserActivity = useCallback(() => {
    resetAutoLockTimer();
  }, [resetAutoLockTimer]);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />

        <BrowserRouter>
          <Routes>
            {/* 👇 passing BLE stuff into Index via props */}
            <Route
              path="/"
              element={
                <Index
                  ble={{
                    connectBLE,
                    toggleLock,
                    locateDevice,
                    isLocked,
                    connected,
                    resetAutoLock: handleUserActivity,
                  }}
                />
              }
            />

            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;