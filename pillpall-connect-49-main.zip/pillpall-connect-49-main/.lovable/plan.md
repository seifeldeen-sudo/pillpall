## Remove Location section from Device tab

Delete the "Device Location" card from `src/components/DeviceScreen.tsx` (the block with the `Navigation`/`MapPin` icons showing "Currently with you" and GPS info).

Also clean up unused imports: remove `MapPin` and `Navigation` from the lucide-react import (kept: `Lock`, `Unlock`, `Loader2`, `Radar`, `Pill`).

The Overview tab's location card is unaffected.