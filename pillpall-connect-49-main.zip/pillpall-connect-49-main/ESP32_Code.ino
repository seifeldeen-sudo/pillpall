#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <ESP32Servo.h>

#define MOTOR_PIN 4
#define BUZZER_PIN 12  // Changed from 10 to 12 - more reliable PWM pin

// Use a 3.3V buzzer on the ESP32 GPIO output
#define SERVICE_UUID        "12345678-1234-1234-1234-123456789abc"
#define CHARACTERISTIC_UUID "abcd1234-1234-1234-123456789abc"

Servo motorServo;

bool isLocked = true;
unsigned long unlockTimestamp = 0;
bool warningPlayed = false;

void setLocked() {
  Serial.println("LOCKED");
  motorServo.write(0);   // return motor to base position
  warningPlayed = false;
}

void setUnlocked() {
  Serial.println("UNLOCKED");
  motorServo.write(60); // move motor to unlock indicator position
  unlockTimestamp = millis();
  warningPlayed = false;
}

void playWarningTone() {
  int toneFreq = 1200;
  for (int i = 0; i < 3; i++) {
    tone(BUZZER_PIN, toneFreq);
    delay(200);
    noTone(BUZZER_PIN);
    delay(150);
  }
}

void playMorseExclamation() {
  // Morse code for !: --..--
  // Dash: 600ms, Dot: 200ms, Symbol space: 200ms, Letter space: 600ms
  int unit = 200;
  int dash = 3 * unit;
  int dot = unit;
  int symbolSpace = unit;
  int letterSpace = 3 * unit;
  int toneFreq = 1000; // Lower frequency for better buzzer response

  auto buzz = [&](int duration) {
    tone(BUZZER_PIN, toneFreq);
    delay(duration);
    noTone(BUZZER_PIN);
  };

  // First dash
  buzz(dash);
  delay(symbolSpace);

  // Second dash
  buzz(dash);
  delay(letterSpace);

  // First dot
  buzz(dot);
  delay(symbolSpace);

  // Second dot
  buzz(dot);
  delay(letterSpace);

  // Third dash
  buzz(dash);
  delay(symbolSpace);

  // Fourth dash
  buzz(dash);
}

// Test buzzer function - call this from setup() to verify buzzer works
void testBuzzer() {
  Serial.println("Testing buzzer...");
  tone(BUZZER_PIN, 1000);
  delay(500);
  noTone(BUZZER_PIN);
  delay(500);
  tone(BUZZER_PIN, 2000);
  delay(500);
  noTone(BUZZER_PIN);
  Serial.println("Buzzer test complete");
}

class MyServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer* pServer) {
    Serial.println("Device connected!");
    // Optional: You could add connection status tracking here
  }

  void onDisconnect(BLEServer* pServer) {
    Serial.println("Device disconnected!");
    // Restart advertising to allow reconnection
    delay(500); // Small delay before restarting advertising
    BLEDevice::startAdvertising();
  }
};

class MyCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *pCharacteristic) {
    String value = pCharacteristic->getValue().c_str();

    Serial.print("Received command: ");
    Serial.println(value);

    if (value.equals("toggle")) {
      isLocked = !isLocked;
      Serial.print("Lock state changed to: ");
      Serial.println(isLocked ? "LOCKED" : "UNLOCKED");

      if (isLocked) {
        setLocked();
      } else {
        setUnlocked();
      }
    } else if (value.equals("locate")) {
      Serial.println("LOCATE COMMAND RECEIVED");
      playMorseExclamation();
    } else {
      Serial.println("Unknown command received");
    }
  }
};

void setup() {
  Serial.begin(115200);

  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  motorServo.attach(MOTOR_PIN);

  setLocked(); // start locked

  // Test buzzer on startup
  testBuzzer();

  BLEDevice::init("PillPall-ESP32");
  Serial.println("BLE Device initialized");

  BLEServer *pServer = BLEDevice::createServer();
  pServer->setCallbacks(new MyServerCallbacks());
  Serial.println("BLE Server created");

  BLEService *pService = pServer->createService(SERVICE_UUID);
  Serial.println("BLE Service created");

  BLECharacteristic *pCharacteristic = pService->createCharacteristic(
    CHARACTERISTIC_UUID,
    BLECharacteristic::PROPERTY_READ |
    BLECharacteristic::PROPERTY_WRITE |
    BLECharacteristic::PROPERTY_NOTIFY
  );

  // Add descriptor for notifications (required for some clients)
  pCharacteristic->addDescriptor(new BLE2902());
  Serial.println("BLE Characteristic created with descriptor");

  pCharacteristic->setCallbacks(new MyCallbacks());
  pCharacteristic->setValue("LOCKED");

  pService->start();
  Serial.println("BLE Service started");

  BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
  pAdvertising->addServiceUUID(SERVICE_UUID);
  pAdvertising->setScanResponse(true);
  pAdvertising->setMinPreferred(0x06);  // functions that help with iPhone connections issue
  pAdvertising->setMinPreferred(0x12);
  pAdvertising->start();
  Serial.println("BLE Advertising started");

  Serial.println("BLE READY");
}

void loop() {
  // Check for 10-second warning
  if (!isLocked && !warningPlayed && unlockTimestamp > 0 && millis() - unlockTimestamp >= 10000) {
    Serial.println("WARNING: unlocked for 10 seconds");
    playWarningTone();
    warningPlayed = true;
  }

  // Small delay for stability
  delay(100);
}